#include <stdio.h>

// function prototypes
void read_cells(int cells[], int num_cells);
void print_cells(int cells[], int num_cells);
void update_cells(int cells[], int num_cells);
void copy_cells(int source[], int dest[], int num_cells);

int main(void) {
	// TODO: add your code here

	return 0;
}

// TODO: add function definitions
