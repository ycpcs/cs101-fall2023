#include<stdio.h>

int main(void) {


  // TODO: add your code for Part 1 here
    



  // TODO: add your code for Part 2 here





}


