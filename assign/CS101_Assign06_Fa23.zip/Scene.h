#ifndef SCENE_H
#define SCENE_H

#include <stdio.h>
#include <stdlib.h>
#include "Console.h"
#include "Const.h"
#include "Player.h"

struct Scene {
	int board[HEIGHT][WIDTH];
	int num_pellets;
	int num_powerups;
	// TODO: add additional fields
	
};

// Scene accessor function prototypes
void initialize_scene(Scene *s);
void render_scene(Scene *s);
int update_scene(Scene *s);
void initialize_board(Scene *s);
void load_board(int board[HEIGHT][WIDTH], int *num_pellets, int *num_powerups);
void draw_board(int board[HEIGHT][WIDTH]);

#endif // SCENE_H
