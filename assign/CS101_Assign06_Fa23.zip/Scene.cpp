#include "Scene.h"

// TODO: Complete scene accessor functions

// Function to initialize scene fields
void initialize_scene(Scene *s)
{
	initialize_board(s);

	//TODO: Initialize player(s)

}

// Function to draw scene fields
void render_scene(Scene *s)
{
	// Render board
	draw_board(s->board);
	
	// TODO: Render player(s)
	
	// TODO: Render score
	
}

// Function to update scene fields
int update_scene(Scene *s)
{
	// TODO: Get player movement and update player


	// TODO: Get ghost(s) movement and update ghost(s)


	// Game keeps going
	return false;
}

// Board functions - DO NOT MODIFY

// Function to read board from text file
void load_board(int board[HEIGHT][WIDTH], int *num_pellets, int *num_powerups)
{
	FILE* in;
	char ch;
	int i,j;
	
	*num_pellets = 0;
	*num_powerups = 0;
	
	in = fopen("board.txt","r");
	if(!in)
	{
		printf("Unable to open file.");
		exit(0);
	}

	for(i=0; i<HEIGHT; i++)
	{
		for(j=0; j<WIDTH; j++)
		{
			fscanf(in,"%c",&ch);
			if(ch=='+')
			{
				board[i][j] = WALL;
			}
			else if(ch=='.')
			{
				board[i][j] = PELLET;
				*num_pellets++;
			}
			else if(ch=='O')
			{
				board[i][j] = POWER_UP;
				*num_powerups++;
			}
			else
			{
				board[i][j] = EMPTY;
			}
		}
		fscanf(in,"%c",&ch);
		fscanf(in,"%c",&ch);
	}

	fclose(in);

	return;
}

// Function to initialize board field from file
void initialize_board(Scene *s)
{
	load_board(s->board, &s->num_pellets, &s->num_powerups);
}

// Render board
void draw_board(int board[HEIGHT][WIDTH])
{
	int i,j;
	int loc;

	cons_change_color(WHITE,BLACK);
	for(i=0; i<HEIGHT; i++)
	{
		for(j=0; j<WIDTH; j++)
		{
			cons_move_cursor(i,j);
			loc = board[i][j];
			cons_change_color(BLACK,BLACK);
			if(loc == WALL)
			{
				cons_change_color(BLUE,BLUE);
				cons_printw("%c",WALL_CHAR);
			}
			else if(loc == PELLET)
			{
				cons_change_color(WHITE,BLACK);
				cons_printw("%c",PELLET_CHAR);
			}
			else if(loc == POWER_UP)
			{
				cons_change_color(BLACK,WHITE);
				cons_printw("%c",POWER_CHAR);
			}
		}
	}
}
