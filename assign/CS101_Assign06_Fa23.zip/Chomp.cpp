#include <stdlib.h>
#include <time.h>
#include "Console.h"
#include "Scene.h"

#define ANIMATION_DELAY 50

// Main - DO NOT MODIFY
int main()
{
	srand(time(0));

	// Create scene
	Scene myScene;

	// Initialize scene
	initialize_scene(&myScene);

	// Main game loop
	int done = false;
	while (!done) {
		cons_clear_screen();
		
		// Draw scene
		render_scene(&myScene);
		
		// Move cursor off screen
		cons_move_cursor(23,79);
		cons_update();
		cons_sleep_ms(ANIMATION_DELAY);

		// Update scene checking for game over
		done = update_scene(&myScene);
	}

	// Print Game Over
	cons_clear_screen();
	render_scene(&myScene);
	cons_move_cursor(23,0);
	cons_change_color(YELLOW,BLACK);
	cons_printw("GAME OVER!");
	cons_update();
	cons_wait_for_keypress();
}
