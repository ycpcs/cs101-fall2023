// CS101 Assignment 3 - Fall 2023
#include <stdio.h>

int main() {
	// TODO: Add your code here
	
	return 0;
}