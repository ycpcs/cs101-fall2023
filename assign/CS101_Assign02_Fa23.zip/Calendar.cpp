# CS101 Assignment 2 - Fall 2023
#include <stdio.h>

int main() {
	// TODO: Add code

	return 0;
}